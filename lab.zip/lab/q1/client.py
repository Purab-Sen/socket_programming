import socket

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(('127.0.0.1',12345))
print("Connect to server")
msg = input("Enter the message:")
s.send(msg.encode())
res = s.recv(1024)
print(f"Got from server:\n{res.decode()}")
s.close()