import socket

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(('127.0.0.1',12345))
s.listen(1)
c, addr = s.accept()
print(f"Got connection from {addr}")
msg = c.recv(1024).decode()
msg = msg.upper()
c.send(msg.encode())
c.close()