import socket

s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
addr = ('127.0.0.1',12345)
print("Connected to server")
msg = input("Enter the message: ")
try:
    s.sendto(msg.encode(),addr)
    print("Data sent to server")
    data,addr = s.recvfrom(1024)
    print(f"Data received from server:\n{data.decode()}")
except:
    print("Couldn't connect to server")
finally:
    s.close()
