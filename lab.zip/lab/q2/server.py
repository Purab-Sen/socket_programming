import socket

s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind(('127.0.0.1',12345))
print("Server is listening ")
data, addr = s.recvfrom(1024)
msg = data.decode()
print(f"Received message: {msg}\n from {addr}")
s.sendto(msg.upper().encode(),addr)
s.close()