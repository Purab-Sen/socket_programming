import socket

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(('127.0.0.1',12345))
print("Connected to server!")
bs = 4096
with open('./received.html','wb') as file:
    while True:
        data = s.recv(bs)
        print(data)
        if not data:
            break
        file.write(data)
    print("File received successfully")
s.close()