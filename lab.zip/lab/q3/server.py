import socket

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
bs = 4096
s.bind(('127.0.0.1',12345))
s.listen(1)
print("Server is listening ...")

c,addr = s.accept()
with open('./serverfile.html','rb') as file:
    while True:
        data = file.read(bs)
        if not data:
            break
        c.sendall(data)
    print("File sent successfully!")
c.close()