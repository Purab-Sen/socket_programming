import socket

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(('127.0.0.1',12345))
s.listen(1)

c,addr = s.accept()
print(f"Received data from {addr}")
data = c.recv(1024).decode()
data = data.split()
a = int(data[0])
b = int(data[1])
ans = str(a + b)
c.send(ans.encode())
c.close()